# IMDB-Sentiment-Analysis-Using-BERT-Fine-Tuning

This repo is for learning how to use do the tasks like sentiment analysis with BERT fine-tuning via Tensorflow Keras.

1) If you are not familiar with the architecture of Transformer and BERT, you can refer to the links below.

Attentiopn Is All You Need (Transformer): https://arxiv.org/abs/1706.03762

BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding: https://arxiv.org/abs/1810.04805

2) If you are a Mandarin reader, you can also refer to my medium articles.

https://haren.medium.com/paper-notes-attention-is-all-you-need-transformer-f33c828239b9

https://haren.medium.com/paper-notes-bert-bert-架構理解-31c014d7dd63

3) The dataset we are going to use in this repo is from kaggle.

https://www.kaggle.com/lakshmi25npathi/imdb-dataset-of-50k-movie-reviews
